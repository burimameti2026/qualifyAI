using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using LeadsAI.Application;
using LeadsAI.Domain;
using LeadsAI.Domain.Core;


namespace LeadsAI.Infrastructure.Acquisition;

public interface IAutonomousAcquisitionJobOrchestrator
{
    Task ExecuteAsync(AgentJob job, CancellationToken ct = default);
}

public sealed class AutonomousAcquisitionJobOrchestrator(
    AppDbContext db,
    IAutonomousAcquisitionTemplateRegistry templates,
    IEnumerable<IProspectDiscoveryProvider> providers,
    IAutonomousAcquisitionBackendService backend,
    ITenantContext tenantContext,
    IAutonomousAcquisitionWorkflowPlanner planner,
    IAgentJobTaskFactory taskFactory,
    ICampaignContainerRuntime containers) : IAutonomousAcquisitionJobOrchestrator
{
    public async Task ExecuteAsync(AgentJob job, CancellationToken ct = default)
    {
        job = await db.AgentJobs.SingleOrDefaultAsync(x => x.TenantId == job.TenantId && x.Id == job.Id, ct)
            ?? throw new InvalidOperationException("Agent job was not found.");

        if (job.Status is not (AgentJobStatus.Queued or AgentJobStatus.Running or AgentJobStatus.Waiting))
            return;

        var campaign = await db.Campaigns
            .SingleOrDefaultAsync(x => x.TenantId == job.TenantId && x.Id == job.CampaignId, ct)
            ?? throw new InvalidOperationException("Campaign was not found for the acquisition job.");

        if (campaign.Status is not CampaignStatus.Running)
        {
            job.Status = campaign.Status == CampaignStatus.Paused
                ? AgentJobStatus.Waiting
                : AgentJobStatus.Cancelled;
            await db.SaveChangesAsync(ct);
            return;
        }

        var agent = await db.AutonomousAcquisitionAgents
            .SingleOrDefaultAsync(x => x.Id == job.AgentId && x.TenantId == job.TenantId, ct)
            ?? throw new InvalidOperationException("Agent was not found.");

        if (agent.Status is AutonomousAgentStatus.Paused)
        {
            job.Status = AgentJobStatus.Waiting;
            await db.SaveChangesAsync(ct);
            return;
        }

        if (agent.Status is AutonomousAgentStatus.Stopped)
        {
            job.Status = AgentJobStatus.Cancelled;
            job.CompletedAtUtc = DateTime.UtcNow;
            await db.SaveChangesAsync(ct);
            return;
        }

        if (agent.Status is not AutonomousAgentStatus.Active)
            throw new InvalidOperationException("Only active agents are allowed to job.");

        if (tenantContext.Current?.Id != job.TenantId)
            throw new InvalidOperationException("Autonomous acquisition job must execute inside its tenant context.");

        var runtimeNow = DateTime.UtcNow;
        job.Status = AgentJobStatus.Running;
        job.StartedAtUtc ??= runtimeNow;
        job.Error = null;

        if (job.ContainerId.HasValue)
        {
            var container = await db.CampaignContainers
                .SingleOrDefaultAsync(x => x.TenantId == job.TenantId && x.Id == job.ContainerId.Value, ct);

            if (container is not null)
                containers.Run(container, runtimeNow);
        }
        job.UpdatedAtUtc = DateTime.UtcNow;

        try
        {
            var template = templates.Apply(agent);
            template = ApplyCampaignPlan(campaign, agent, template);
            await planner.EnsurePlanAsync(agent, template, ct, campaign.PlanJson);
            var tasks = await taskFactory.EnsureAsync(job, agent, template, campaign.PlanJson, ct);
            var now = DateTime.UtcNow;

            var awaitingApproval = false;
            var current = tasks
                .Where(x => x.Status != AutonomousAgentTaskStatus.Completed)
                .OrderBy(x => x.Sequence)
                .FirstOrDefault();

            var visited = new HashSet<Guid>();
            while (current is not null && visited.Add(current.Id))
            {
                if (!await CanContinueAsync(job, agent, ct))
                    return;

                awaitingApproval = await ExecuteTaskAsync(current, job, agent, template, tasks, now, ct);
                if (awaitingApproval)
                    break;

                var nextType = ReadNextStep(current.ConfigurationJson);
                current = string.IsNullOrWhiteSpace(nextType)
                    ? tasks.Where(x => x.Status != AutonomousAgentTaskStatus.Completed).OrderBy(x => x.Sequence).FirstOrDefault()
                    : tasks.FirstOrDefault(x => x.Type == nextType && x.Status != AutonomousAgentTaskStatus.Completed);
            }

            agent.LastRunAtUtc = now;
            agent.UpdatedAtUtc = now;

            if (awaitingApproval)
            {
                job.Status = AgentJobStatus.Waiting;
                job.CompletedAtUtc = null;
            }
            else
            {
                job.Status = AgentJobStatus.Completed;
                job.CompletedAtUtc = DateTime.UtcNow;
            }

            job.UpdatedAtUtc = DateTime.UtcNow;
            await db.SaveChangesAsync(ct);
        }
        catch (Exception ex)
        {
            var runningTask = await db.AutonomousAcquisitionTasks
                .FirstOrDefaultAsync(x => x.TenantId == job.TenantId &&
                                           x.AgentId == job.AgentId &&
                                           x.RunId == job.Id &&
                                           x.Status == AutonomousAgentTaskStatus.Running,
                    CancellationToken.None);

            if (runningTask is not null)
            {
                runningTask.Status = AutonomousAgentTaskStatus.Failed;
                runningTask.Error = ex.Message;
                runningTask.CompletedAtUtc = DateTime.UtcNow;
                runningTask.UpdatedAtUtc = DateTime.UtcNow;
            }

            job.Status = AgentJobStatus.Failed;
            job.Error = ex.Message;
            job.CompletedAtUtc = DateTime.UtcNow;
            job.LeaseUntilUtc = null;
            job.WorkerId = null;
            job.UpdatedAtUtc = DateTime.UtcNow;
            if (job.ContainerId.HasValue)
            {
                db.AuditLogs.Add(new AuditLog
                {
                    TenantId = job.TenantId,
                    Action = "container.failed",
                    EntityType = "CampaignContainerActivity",
                    EntityId = job.ContainerId.Value.ToString(),
                    DataJson = JsonSerializer.Serialize(new { level = "error", jobId = job.Id, message = $"Container job failed: {ex.Message}", error = ex.Message })
                });
            }

            if (agent.Status == AutonomousAgentStatus.Active)
                agent.UpdatedAtUtc = DateTime.UtcNow;

            await db.SaveChangesAsync(CancellationToken.None);
            throw;
        }
    }

    private static AutonomousAcquisitionTemplate ApplyCampaignPlan(
        Campaign campaign,
        AutonomousAcquisitionAgent agent,
        AutonomousAcquisitionTemplate fallback)
    {
        if (string.IsNullOrWhiteSpace(campaign.PlanJson))
            return fallback;

        try
        {
            using var document = JsonDocument.Parse(campaign.PlanJson);
            var root = document.RootElement;

            var industry = ReadString(root, "industry");
            var region = ReadString(root, "region");

            if (!string.IsNullOrWhiteSpace(industry))
                agent.Industry = industry;
            if (!string.IsNullOrWhiteSpace(region))
                agent.Region = region;

            var keywords = fallback.Keywords;
            var signals = fallback.Signals;
            var minimumScore = fallback.MinimumScore;

            if (TryStageConfig(root, "Discovery", out var discovery))
            {
                var configuredKeywords = ReadStringArray(discovery, "keywords");
                if (configuredKeywords.Length > 0)
                    keywords = configuredKeywords;

                var discoveryRegion = ReadString(discovery, "region");
                if (!string.IsNullOrWhiteSpace(discoveryRegion))
                    agent.Region = discoveryRegion;

                var maxResults = ReadInt(discovery, "maxResults");
                if (maxResults > 0)
                    agent.DailyDiscoveryLimit = Math.Clamp(maxResults, 1, 100);
            }

            if (TryStageConfig(root, "Qualification", out var qualification))
            {
                var configuredMinimum = ReadInt(qualification, "minimumScore");
                if (configuredMinimum > 0)
                    minimumScore = configuredMinimum;

                var configuredSignals = ReadStringArray(qualification, "intentSignals");
                if (configuredSignals.Length > 0)
                    signals = configuredSignals;
            }

            agent.MinimumScore = Math.Clamp(minimumScore, 0, 100);

            var messages = fallback.OutreachTemplates;
            if (TryStageConfig(root, "Outreach", out var outreach) &&
                outreach.TryGetProperty("steps", out var steps) &&
                steps.ValueKind == JsonValueKind.Array)
            {
                var configuredMessages = steps.EnumerateArray()
                    .Select((step, index) => new AutonomousAcquisitionMessageTemplate(
                        ReadInt(step, "step") > 0 ? ReadInt(step, "step") : index + 1,
                        ReadString(step, "name") is { Length: > 0 } name ? name : $"Step {index + 1}",
                        ReadString(step, "subject"),
                        ReadString(step, "body"),
                        ReadInt(step, "delayHours"),
                        ReadBool(step, "requiresApproval")))
                    .Where(x => !string.IsNullOrWhiteSpace(x.Subject) || !string.IsNullOrWhiteSpace(x.Body))
                    .ToArray();

                if (configuredMessages.Length > 0)
                    messages = configuredMessages;
            }

            return new AutonomousAcquisitionTemplate(
                fallback.Code,
                fallback.Name,
                string.IsNullOrWhiteSpace(industry) ? fallback.Industry : industry,
                string.IsNullOrWhiteSpace(region) ? fallback.Region : region,
                keywords,
                signals,
                agent.MinimumScore,
                fallback.Description,
                fallback.ProspectType,
                fallback.TargetDefinition,
                messages.ToArray());
        }
        catch (JsonException)
        {
            return fallback;
        }
    }

    private static bool TryStageConfig(JsonElement root, string type, out JsonElement config)
    {
        config = default;

        if (!root.TryGetProperty("stages", out var stages) || stages.ValueKind != JsonValueKind.Array)
            return false;

        foreach (var stage in stages.EnumerateArray())
        {
            if (!stage.TryGetProperty("type", out var stageType) ||
                !string.Equals(stageType.GetString(), type, StringComparison.OrdinalIgnoreCase))
                continue;

            if (stage.TryGetProperty("config", out config) && config.ValueKind == JsonValueKind.Object)
                return true;
        }

        return false;
    }

    private static string ReadString(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? string.Empty
            : string.Empty;

    private static int ReadInt(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.TryGetInt32(out var number)
            ? number
            : 0;

    private static bool ReadBool(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) &&
        (value.ValueKind == JsonValueKind.True || value.ValueKind == JsonValueKind.False) &&
        value.GetBoolean();

    private static string[] ReadStringArray(JsonElement element, string property)
    {
        if (!element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.Array)
            return [];

        return value.EnumerateArray()
            .Where(x => x.ValueKind == JsonValueKind.String)
            .Select(x => x.GetString() ?? string.Empty)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .ToArray();
    }

    private static string ReadNextStep(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json);
            return doc.RootElement.TryGetProperty("nextStep", out var value)
                ? value.GetString() ?? string.Empty
                : string.Empty;
        }
        catch { return string.Empty; }
    }

    private async Task<bool> ExecuteTaskAsync(
        AutonomousAcquisitionTask task,
        AgentJob job,
        AutonomousAcquisitionAgent agent,
        AutonomousAcquisitionTemplate template,
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        DateTime now,
        CancellationToken ct)
    {
        await LogActivityAsync(job, task, "info", "step.started", $"Started {task.Name}.", new { sequence = task.Sequence }, ct);
        try
        {
            var waiting = task.Type switch
            {
                AutonomousAgentTaskTypes.Discover => await ExecuteDiscoveryAndContinueAsync(task, job, agent, template, tasks, now, ct),
                AutonomousAgentTaskTypes.Qualify => await ExecuteQualificationAndContinueAsync(task, job, agent, tasks, ct),
                AutonomousAgentTaskTypes.Enrich => await ExecuteEnrichmentAndContinueAsync(task, job, agent, tasks, ct),
                AutonomousAgentTaskTypes.BuildTargetList => await ExecuteTargetListAndContinueAsync(task, job, agent, tasks, ct),
                AutonomousAgentTaskTypes.Outreach => await PrepareOutreachAsync(job, agent, template, tasks, ct),
                _ => throw new InvalidOperationException($"No executor is registered for acquisition task '{task.Type}'.")
            };
            if (waiting)
                await LogActivityAsync(job, task, "warning", "step.waiting", $"{task.Name} is waiting for approval.", new { status = "waiting-approval" }, ct);
            else
                await LogActivityAsync(job, task, "info", "step.completed", BuildTaskSummary(task), null, ct);
            return waiting;
        }
        catch (Exception ex)
        {
            await LogActivityAsync(job, task, "error", "step.failed", $"{task.Name} failed: {ex.Message}", new { error = ex.Message }, CancellationToken.None);
            throw;
        }
    }

    private async Task LogActivityAsync(
        AgentJob job,
        AutonomousAcquisitionTask task,
        string level,
        string eventType,
        string message,
        object? data,
        CancellationToken ct)
    {
        if (!job.ContainerId.HasValue) return;
        db.AuditLogs.Add(new AuditLog
        {
            TenantId = job.TenantId,
            Action = eventType,
            EntityType = "CampaignContainerActivity",
            EntityId = job.ContainerId.Value.ToString(),
            DataJson = JsonSerializer.Serialize(new { level, jobId = job.Id, taskId = task.Id, stepType = task.Type, stepName = task.Name, message, data })
        });
        await db.SaveChangesAsync(ct);
    }

    private static string BuildTaskSummary(AutonomousAcquisitionTask task)
    {
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(task.ResultJson) ? "{}" : task.ResultJson);
            var root = doc.RootElement;
            return task.Type switch
            {
                AutonomousAgentTaskTypes.Discover => $"Discovery completed: found {ReadJsonInt(root, "discovered")} prospects.",
                AutonomousAgentTaskTypes.Qualify => $"Qualification completed: processed {ReadJsonInt(root, "processed")} prospects, {ReadJsonInt(root, "qualified")} qualified.",
                AutonomousAgentTaskTypes.Enrich => $"Enrichment completed: {ReadJsonInt(root, "enriched")} qualified prospects have evidence.",
                AutonomousAgentTaskTypes.BuildTargetList => $"Target list completed: added {ReadJsonInt(root, "added")} prospects.",
                AutonomousAgentTaskTypes.Outreach => $"Outreach preparation completed: prepared {ReadJsonInt(root, "prepared")} messages; approval required.",
                _ => $"{task.Name} completed."
            };
        }
        catch { return $"{task.Name} completed."; }
    }

    private static int ReadJsonInt(JsonElement root, string property) =>
        root.TryGetProperty(property, out var value) && value.TryGetInt32(out var number) ? number : 0;

    private async Task<bool> ExecuteDiscoveryAndContinueAsync(AutonomousAcquisitionTask task, AgentJob job, AutonomousAcquisitionAgent agent, AutonomousAcquisitionTemplate templateAgentTemplate, IReadOnlyList<AutonomousAcquisitionTask> tasks, DateTime now, CancellationToken ct)
    {
        await ExecuteDiscoveryAsync(job, agent, templateAgentTemplate, tasks, now, ct);
        return false;
    }

    private async Task<bool> ExecuteQualificationAndContinueAsync(AutonomousAcquisitionTask task, AgentJob job, AutonomousAcquisitionAgent agent, IReadOnlyList<AutonomousAcquisitionTask> tasks, CancellationToken ct)
    {
        await ExecuteQualificationAsync(job, agent, tasks, ct);
        return false;
    }

    private async Task<bool> ExecuteEnrichmentAndContinueAsync(AutonomousAcquisitionTask task, AgentJob job, AutonomousAcquisitionAgent agent, IReadOnlyList<AutonomousAcquisitionTask> tasks, CancellationToken ct)
    {
        await ExecuteEnrichmentAsync(job, agent, tasks, ct);
        return false;
    }

    private async Task<bool> ExecuteTargetListAndContinueAsync(AutonomousAcquisitionTask task, AgentJob job, AutonomousAcquisitionAgent agent, IReadOnlyList<AutonomousAcquisitionTask> tasks, CancellationToken ct)
    {
        await ExecuteTargetListAsync(job, agent, tasks, ct);
        return false;
    }

    private async Task<bool> CanContinueAsync(AgentJob job, AutonomousAcquisitionAgent agent, CancellationToken ct)
    {
        var campaign = await db.Campaigns.SingleAsync(x => x.TenantId == job.TenantId && x.Id == job.CampaignId, ct);
        if (campaign.Status == CampaignStatus.Paused || agent.Status == AutonomousAgentStatus.Paused)
        {
            job.Status =AgentJobStatus.Waiting;
            job.CompletedAtUtc = null;
            await db.SaveChangesAsync(ct);
            return false;
        }

        if (campaign.Status is CampaignStatus.Stopped or CampaignStatus.Completed || agent.Status is AutonomousAgentStatus.Stopped)
        {
            job.Status = AgentJobStatus.Cancelled;
            job.CompletedAtUtc = DateTime.UtcNow;
            await db.SaveChangesAsync(ct);
            return false;
        }

        return campaign.Status == CampaignStatus.Running && agent.Status == AutonomousAgentStatus.Active;
    }

    private async Task ExecuteDiscoveryAsync(
        AgentJob job,
        AutonomousAcquisitionAgent agent,
        AutonomousAcquisitionTemplate template,
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        DateTime now,
        CancellationToken ct)
    {
        var task = StartTask(tasks, AutonomousAgentTaskTypes.Discover);
        var countries = ReadCountries(agent.CountriesJson);
        var country = countries.Count == 0
            ? string.Empty
            : countries[(int)(DateTime.UtcNow.Ticks % countries.Count)];

        job.Query = await backend.SelectNextQueryAsync(agent, template, ct);

        var campaign = await db.Campaigns
            .SingleOrDefaultAsync(x => x.TenantId == job.TenantId && x.Id == job.CampaignId, ct)
            ?? throw new InvalidOperationException("Campaign container was not found for the acquisition job.");

        var targetListId = await GetJobTargetListIdAsync(job, campaign, ct);
        if (targetListId.HasValue)
        {
            var existingProspects = await (
                from member in db.TargetListMembers.AsNoTracking()
                join prospect in db.Prospects.AsNoTracking() on member.ProspectId equals prospect.Id
                where member.TenantId == job.TenantId &&
                      member.TargetListId == targetListId.Value &&
                      prospect.TenantId == job.TenantId
                select prospect.Id)
                .Take(Math.Clamp(agent.DailyDiscoveryLimit, 1, 100))
                .ToListAsync(ct);

            job.DiscoveredCount = existingProspects.Count;
            CompleteTask(task, new { discovered = job.DiscoveredCount, source = "prospect-group", targetListId });
            return;
        }

        var icpId = await db.TargetLists
            .Where(x => x.TenantId == job.TenantId && x.Id == campaign.TargetListId)
            .Select(x => x.IcpProfileId)
            .FirstOrDefaultAsync(ct);

        var icp = icpId.HasValue
            ? await db.IcpProfiles.SingleOrDefaultAsync(x => x.TenantId == job.TenantId && x.Id == icpId.Value && x.Active, ct)
            : null;

        icp ??= new IcpProfile
        {
            TenantId = agent.TenantId,
            Name = $"{campaign.Name} ICP",
            Industry = string.IsNullOrWhiteSpace(agent.Industry) ? template.Industry : agent.Industry,
            CountriesCsv = string.Join(',', countries),
            IntentKeywordsCsv = string.Join(',', template.Keywords),
            CriteriaJson = agent.IcpJson,
            Active = true
        };

        var provider = providers.FirstOrDefault(x => x.IsConfigured)
            ?? throw new InvalidOperationException("No configured prospect discovery provider is available.");

        var candidates = await provider.SearchAsync(
            icp,
            new DiscoveryRunOptions(
                provider.Name,
                string.IsNullOrWhiteSpace(agent.Region) ? template.Region : agent.Region,
                Math.Clamp(agent.DailyDiscoveryLimit, 1, 100),
                0,
                CreateTargetList: false,
                TenantId: agent.TenantId),
            ct);

        job.DiscoveredCount = candidates.Count;

        var existing = await db.Prospects.Where(x => x.TenantId == agent.TenantId)
            .Select(x => x.Domain)
            .ToListAsync(ct);

        var known = new HashSet<string>(
            existing.Where(x => !string.IsNullOrWhiteSpace(x)).Select(Normalize),
            StringComparer.OrdinalIgnoreCase);

        foreach (var candidate in candidates)
        {
            var domain = Normalize(candidate.Domain);
            if (string.IsNullOrWhiteSpace(domain) || known.Contains(domain))
                continue;

            known.Add(domain);
            var prospect = new Prospect
            {
                TenantId = agent.TenantId,
                CompanyName = candidate.CompanyName,
                Domain = domain,
                Industry = candidate.Industry ?? agent.Industry,
                Country = string.IsNullOrWhiteSpace(candidate.Country) ? country : candidate.Country,
                Source = provider.Name,
                SourceUrl = candidate.SourceUrl,
                DatasetOrigin = $"autonomous-agent:{job.CampaignId:N}",
                VerificationStatus = "public-source",
                ContactReadiness = "company-only",
                SizeBand = "unknown",
                Status = ProspectStatus.Discovered,
                SuggestedBuyer = "Needs enrichment",
                Priority = "medium",
                OutreachStatus = "not-ready",
                PainHypothesis = "Evidence-based research pending.",
                CreatedAtUtc = now,
                UpdatedAtUtc = now
            };

            db.Prospects.Add(prospect);
            db.ProspectSignals.Add(new ProspectSignal
            {
                TenantId = agent.TenantId,
                ProspectId = prospect.Id,
                Type = "autonomous-discovery",
                Source = provider.Name,
                Evidence = candidate.Evidence,
                Score = 0,
                SourceUrl = candidate.SourceUrl,
                ObservedAtUtc = now
            });
        }

        await db.SaveChangesAsync(ct);
        CompleteTask(task, new { discovered = job.DiscoveredCount, next = AutonomousAgentTaskTypes.Qualify });
    }

    private async Task ExecuteQualificationAsync(
        AgentJob job,
        AutonomousAcquisitionAgent agent,
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        CancellationToken ct)
    {
        var task = StartTask(tasks, AutonomousAgentTaskTypes.Qualify);
        var campaign = await db.Campaigns.SingleAsync(x => x.TenantId == job.TenantId && x.Id == job.CampaignId, ct);
        var targetListId = await GetJobTargetListIdAsync(job, campaign, ct);
        List<Prospect> prospects;
        if (targetListId.HasValue)
        {
            prospects = await (
                from member in db.TargetListMembers
                join prospect in db.Prospects on member.ProspectId equals prospect.Id
                where member.TenantId == agent.TenantId &&
                      member.TargetListId == targetListId.Value &&
                      prospect.TenantId == agent.TenantId
                orderby prospect.UpdatedAtUtc descending
                select prospect)
                .Take(Math.Clamp(agent.DailyDiscoveryLimit, 1, 100))
                .ToListAsync(ct);
        }
        else
        {
            var since = job.StartedAtUtc ?? DateTime.UtcNow;
            prospects = await db.Prospects
                .Where(x => x.TenantId == agent.TenantId && x.CreatedAtUtc >= since && x.DatasetOrigin == $"autonomous-agent:{job.CampaignId:N}")
                .OrderByDescending(x => x.CreatedAtUtc)
                .Take(Math.Clamp(agent.DailyDiscoveryLimit, 1, 100))
                .ToListAsync(ct);
        }

        foreach (var prospect in prospects)
        {
            var result = await backend.ResearchAsync(agent.TenantId, agent.Id, prospect, agent.MinimumScore, ct);
            if (result.Qualified) job.QualifiedCount++;
            if (result.Score >= agent.MinimumScore) job.HighScoreCount++;
        }

        CompleteTask(task, new { processed = prospects.Count, qualified = job.QualifiedCount, threshold = agent.MinimumScore });
        await db.SaveChangesAsync(ct);
    }

    private async Task ExecuteEnrichmentAsync(
        AgentJob job,
        AutonomousAcquisitionAgent agent,
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        CancellationToken ct)
    {
        var task = StartTask(tasks, AutonomousAgentTaskTypes.Enrich);
        var campaign = await db.Campaigns.SingleAsync(x => x.TenantId == job.TenantId && x.Id == job.CampaignId, ct);
        var targetListId = await GetJobTargetListIdAsync(job, campaign, ct);
        var count = targetListId.HasValue
            ? await (from member in db.TargetListMembers
                     join prospect in db.Prospects on member.ProspectId equals prospect.Id
                     where member.TenantId == agent.TenantId &&
                           member.TargetListId == targetListId.Value &&
                           prospect.TenantId == agent.TenantId &&
                           prospect.Status == ProspectStatus.Qualified
                     select prospect.Id).CountAsync(ct)
            : await db.Prospects.CountAsync(x =>
                x.TenantId == agent.TenantId &&
                x.CreatedAtUtc >= (job.StartedAtUtc ?? DateTime.UtcNow) &&
                x.DatasetOrigin == $"autonomous-agent:{job.CampaignId:N}" &&
                x.Status == ProspectStatus.Qualified, ct);

        CompleteTask(task, new
        {
            enriched = count,
            mode = "evidence-preserving",
            note = "Company enrichment is currently based on discovered public evidence; no contact data is fabricated."
        });
    }

    private async Task ExecuteTargetListAsync(
        AgentJob job,
        AutonomousAcquisitionAgent agent,
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        CancellationToken ct)
    {
        var task = StartTask(tasks, AutonomousAgentTaskTypes.BuildTargetList);
        var campaign = await db.Campaigns
            .SingleOrDefaultAsync(x => x.TenantId == agent.TenantId && x.Id == job.CampaignId, ct);

        if (campaign is null)
        {
            CompleteTask(task, new { added = 0, note = "No campaign container is linked to this agent." });
            return;
        }

        var since = job.StartedAtUtc ?? DateTime.UtcNow;
        var prospects = await db.Prospects
            .Where(x => x.TenantId == agent.TenantId &&
                        x.CreatedAtUtc >= since &&
                        x.DatasetOrigin == $"autonomous-agent:{job.CampaignId:N}" &&
                        x.Status == ProspectStatus.Qualified)
            .ToListAsync(ct);

        var existing = await db.TargetListMembers
            .Where(x => x.TenantId == agent.TenantId && x.TargetListId == campaign.TargetListId)
            .Select(x => x.ProspectId)
            .ToListAsync(ct);

        var known = existing.ToHashSet();
        var added = 0;
        foreach (var prospect in prospects)
        {
            if (!known.Add(prospect.Id)) continue;
            db.TargetListMembers.Add(new TargetListMember
            {
                TenantId = agent.TenantId,
                TargetListId = campaign.TargetListId,
                ProspectId = prospect.Id,
                AddedAtUtc = DateTime.UtcNow
            });
            added++;
        }

        await db.SaveChangesAsync(ct);
        CompleteTask(task, new { added, targetListId = campaign.TargetListId });
    }

    private async Task<bool> PrepareOutreachAsync(
        AgentJob job,
        AutonomousAcquisitionAgent agent,
        AutonomousAcquisitionTemplate template,
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        CancellationToken ct)
    {
        var task = StartTask(tasks, AutonomousAgentTaskTypes.Outreach);
        var campaign = await db.Campaigns
            .SingleOrDefaultAsync(x => x.TenantId == agent.TenantId && x.Id == job.CampaignId, ct);

        if (campaign is null)
        {
            CompleteTask(task, new { prepared = 0, note = "No campaign container is linked to this agent." });
            return false;
        }

        var existingSteps = await db.CampaignSteps
            .Where(x => x.TenantId == agent.TenantId && x.CampaignId == campaign.Id)
            .ToListAsync(ct);

        foreach (var message in template.OutreachTemplates.OrderBy(x => x.Step))
        {
            var step = existingSteps.FirstOrDefault(x => x.StepNumber == message.Step);
            if (step is null)
            {
                db.CampaignSteps.Add(new CampaignStep
                {
                    TenantId = agent.TenantId,
                    CampaignId = campaign.Id,
                    StepNumber = message.Step,
                    DelayHours = message.DelayHours,
                    Channel = "email",
                    SubjectTemplate = message.Subject,
                    BodyTemplate = message.Body,
                    RulesJson = JsonSerializer.Serialize(new { requiresApproval = true })
                });
            }
        }

        await db.SaveChangesAsync(ct);

        existingSteps = await db.CampaignSteps
            .Where(x => x.TenantId == agent.TenantId && x.CampaignId == campaign.Id)
            .ToListAsync(ct);

        var outreachTargetListId = await GetJobTargetListIdAsync(job, campaign, ct) ?? campaign.TargetListId;
        var members = await db.TargetListMembers
            .Where(x => x.TenantId == agent.TenantId && x.TargetListId == outreachTargetListId)
            .Select(x => x.ProspectId)
            .ToListAsync(ct);

        var existingRecipients = await db.CampaignRecipients
            .Where(x => x.TenantId == agent.TenantId && x.CampaignId == campaign.Id)
            .Select(x => x.ProspectId)
            .ToListAsync(ct);

        var knownRecipients = existingRecipients.ToHashSet();
        var prepared = 0;
        var firstTemplate = template.OutreachTemplates.OrderBy(x => x.Step).FirstOrDefault();

        if (firstTemplate is null)
        {
            CompleteTask(task, new { prepared = 0, requiresApproval = true, next = "no outreach template configured" });
            return false;
        }

        foreach (var prospectId in members)
        {
            if (!knownRecipients.Add(prospectId)) continue;
            var prospect = await db.Prospects.SingleOrDefaultAsync(
                x => x.TenantId == agent.TenantId && x.Id == prospectId,
                ct);
            if (prospect is null || prospect.Status != ProspectStatus.Qualified) continue;
            if (!await backend.CanContactAsync(agent.TenantId, prospect, agent.DailyEmailLimit, ct)) continue;

            var recipient = new CampaignRecipient
            {
                TenantId = agent.TenantId,
                CampaignId = campaign.Id,
                ProspectId = prospect.Id,
                CurrentStep = firstTemplate.Step,
                Status = "pending-approval",
                NextRunAtUtc = null
            };
            db.CampaignRecipients.Add(recipient);

            var step = existingSteps.FirstOrDefault(x => x.StepNumber == firstTemplate.Step);
            if (step is null) continue;

            var message = new OutreachMessage
            {
                TenantId = agent.TenantId,
                CampaignId = campaign.Id,
                ProspectId = prospect.Id,
                CampaignStepId = step.Id,
                Channel = step.Channel,
                Subject = CampaignExecutionService.RenderTemplate(step.SubjectTemplate, prospect),
                Body = CampaignExecutionService.RenderTemplate(step.BodyTemplate, prospect),
                Status = OutreachStatus.Queued
            };
            db.OutreachMessages.Add(message);

            var approvalTitle = $"APPROVAL: Send outreach {message.Id}";
            db.CrmTasks.Add(new CrmTask
            {
                TenantId = agent.TenantId,
                Title = approvalTitle,
                DueAtUtc = DateTime.UtcNow.AddHours(4)
            });

            prepared++;
        }

        await db.SaveChangesAsync(ct);

        CompleteTask(task, new
        {
            prepared,
            requiresApproval = true,
            next = "campaign approval"
        });
        return prepared > 0;
    }

    private async Task<bool> HasPendingApprovalAsync(AgentJob job, AutonomousAcquisitionAgent agent, CancellationToken ct)
    {
        var campaign = await db.Campaigns.SingleOrDefaultAsync(x => x.TenantId == agent.TenantId && x.Id == job.CampaignId, ct);
        if (campaign is null) return false;
        return await db.OutreachMessages.AnyAsync(x =>
            x.TenantId == job.TenantId && x.CampaignId == campaign.Id && x.Status == OutreachStatus.Queued &&
            db.CrmTasks.Any(t => t.TenantId == job.TenantId && t.Title == $"APPROVAL: Send outreach {x.Id}" && !t.Completed), ct);
    }

    private async Task<Guid?> GetJobTargetListIdAsync(
        AgentJob job,
        Campaign campaign,
        CancellationToken ct)
    {
        if (job.ContainerId.HasValue)
        {
            var configuration = await db.CampaignContainers.AsNoTracking()
                .Where(x => x.TenantId == job.TenantId && x.Id == job.ContainerId.Value)
                .Select(x => x.ConfigurationJson)
                .SingleOrDefaultAsync(ct);

            if (!string.IsNullOrWhiteSpace(configuration))
            {
                try
                {
                    using var document = JsonDocument.Parse(configuration);
                    if (document.RootElement.TryGetProperty("targetListId", out var value) &&
                        value.ValueKind == JsonValueKind.String &&
                        Guid.TryParse(value.GetString(), out var containerTargetId) &&
                        await db.TargetLists.AnyAsync(x => x.TenantId == job.TenantId && x.Id == containerTargetId, ct))
                        return containerTargetId;
                }
                catch (JsonException) { }
            }
        }

        return null;
    }

    private static bool IsCompleted(IReadOnlyList<AutonomousAcquisitionTask> tasks, string type) =>
        tasks.Any(x => x.Type == type && x.Status == AutonomousAgentTaskStatus.Completed);

    private static AutonomousAcquisitionTask StartTask(
        IReadOnlyList<AutonomousAcquisitionTask> tasks,
        string type)
    {
        var task = tasks.First(x => x.Type == type);
        task.Status = AutonomousAgentTaskStatus.Running;
        task.AttemptCount++;
        task.StartedAtUtc = DateTime.UtcNow;
        task.CompletedAtUtc = null;
        task.Error = null;
        task.UpdatedAtUtc = DateTime.UtcNow;
        return task;
    }

    private static void CompleteTask(AutonomousAcquisitionTask task, object result)
    {
        task.Status = AutonomousAgentTaskStatus.Completed;
        task.ResultJson = JsonSerializer.Serialize(result);
        task.CompletedAtUtc = DateTime.UtcNow;
        task.UpdatedAtUtc = DateTime.UtcNow;
    }

    private static List<string> ReadCountries(string json)
    {
        try { return JsonSerializer.Deserialize<List<string>>(json) ?? []; }
        catch { return []; }
    }

    private static string Normalize(string? value) =>
        string.IsNullOrWhiteSpace(value)
            ? string.Empty
            : value.Trim().ToLowerInvariant()
                .Replace("https://", string.Empty)
                .Replace("http://", string.Empty)
                .Trim('/')
                .Replace("www.", string.Empty);
}