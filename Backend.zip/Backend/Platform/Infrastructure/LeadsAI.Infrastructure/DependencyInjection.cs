using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using LeadsAI.Application;
using LeadsAI.Application.Abstractions.Persistence;
using LeadsAI.Infrastructure.Messaging.Consumers;
using LeadsAI.Infrastructure.Acquisition;
using LeadsAI.Infrastructure.Automation;
using LeadsAI.Infrastructure.Email;
using LeadsAI.Infrastructure.Demo;
using LeadsAI.Persistence.SqlServer.Repositories;
using LeadsAI.Infrastructure.IndustryPacks;

namespace LeadsAI.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddBusinessInfrastructure(this IServiceCollection services, IConfiguration configuration, bool allowDevelopmentModelDrift = false)
    {
        services.AddSingleton<ITenantDatabaseConnectionResolver, TenantDatabaseConnectionResolver>();
        services.AddScoped<ITenantContext, TenantContext>();
        services.AddDbContext<AppDbContext>((serviceProvider, options) =>
        {
            var tenantContext = serviceProvider.GetRequiredService<ITenantContext>();
            var connectionResolver = serviceProvider.GetRequiredService<ITenantDatabaseConnectionResolver>();
            var connectionString = connectionResolver.ResolveConnectionString(tenantContext.Current);
            options.UseSqlServer(connectionString, sql => sql.EnableRetryOnFailure());
            if (allowDevelopmentModelDrift) options.ConfigureWarnings(w => w.Ignore(RelationalEventId.PendingModelChangesWarning));
        });

        services.AddSingleton<ITenantLifecycleEventStore, TenantLifecycleEventStore>();
        services.AddSingleton<ITenantAlertService, TenantAlertService>();
        services.AddScoped<ITenantLifecycleHealthService, TenantLifecycleHealthService>();
        services.AddSingleton(new BillingLifecyclePolicy());
        services.AddSingleton<IBillingLifecycleEngine, BillingLifecycleEngine>();
        services.AddScoped<IUsageMeter, PersistentUsageMeter>();
        services.AddScoped<IBillingQuotaEnforcer, BillingQuotaEnforcer>();
        services.AddScoped<IBillingAlertSink, PersistentBillingAlertSink>();
        services.AddScoped<IBillingEventProcessor, BillingEventProcessor>();
        services.AddScoped<IBillingProvider, StripeBillingProvider>();
        services.AddScoped<BillingProviderRegistry>();
        services.AddScoped<IBusinessUnitOfWork, BusinessUnitOfWork>();
        services.AddScoped<ICrmRepository, CrmRepository>();
        services.AddScoped<ISupportRepository, SupportRepository>();
        services.AddScoped<IKnowledgeAiRepository, KnowledgeAiRepository>();
        services.AddScoped<IWorkflowAutomationRepository, WorkflowAutomationRepository>();
        services.AddScoped<ITenantEntitlementRepository, TenantEntitlementRepository>();
        services.AddScoped<IdentityEntitlementInboxProcessor>();
        services.AddScoped<IGoldenPipelineProvisioner, GoldenPipelineProvisioner>();
        services.AddScoped<IModuleProvisioner, GoldenPipelineModuleProvisioner>();
        foreach (var moduleCode in new[]
        {
            "crm", "production", "bom", "quality", "maintenance", "suppliers",
            "shipments", "routes", "fleet", "drivers", "dispatch",
            "inventory", "receiving", "putaway", "picking", "packing", "cycle_counts",
            "orders", "inventory_allocation", "replenishment", "pricing",
            "delivery_orders", "stops", "proof_of_delivery", "returns",
            "multi_client", "slas", "billing", "carrier_management",
            "products", "fulfillment", "customers",
            "projects", "work_orders", "materials", "technicians", "scheduling", "service_slas",
            "traceability", "ai_agents", "automations"
        })
            services.AddScoped<IModuleProvisioner>(_ => new RegisteredModuleProvisioner(moduleCode));
        services.AddScoped<IModuleLifecycleHandler, GoldenPipelineModuleLifecycleHandler>();
        services.AddScoped<IModuleRegistry, ModuleRegistry>();
        services.AddScoped<IModuleProvisioningOrchestrator, ModuleProvisioningOrchestrator>();
        services.AddScoped<IModuleDeactivationOrchestrator, ModuleDeactivationOrchestrator>();
        services.AddScoped<ITenantLifecycleOrchestrator, TenantLifecycleOrchestrator>();
        services.AddScoped<ILicenseChangeOrchestrator, LicenseChangeOrchestrator>();
        services.AddScoped<TenantWorkerRuntime>();
        services.AddHostedService<ModuleProvisioningRetryWorker>();
        services.AddHostedService<LicenseExpirationWorker>();
        services.AddHostedService<TenantLifecycleReconciliationWorker>();
        services.AddHostedService<AutonomousAcquisitionSchedulerWorker>();
        services.AddHostedService<OutreachDeliveryWorker>();
        services.AddHostedService<CampaignExecutionWorker>();
        services.AddScoped<IPasswordService, PasswordService>();
        services.AddScoped<IKnowledgeRetriever, SqlKnowledgeRetriever>();
        services.AddHttpClient<OpenRouterAiProvider>();
        services.AddScoped<IAiProvider>(sp => sp.GetRequiredService<OpenRouterAiProvider>());
        services.AddScoped<IAiAgent, AiAgent>();
        services.AddScoped<IAiTool, CreateLeadTool>();
        services.AddScoped<IAiTool, CreateTicketTool>();
        services.AddScoped<IAiTool, SearchKnowledgeTool>();
        services.AddScoped<IAiTool, SearchProspectsTool>();
        services.AddScoped<IAiTool, CreateIcpTool>();
        services.AddScoped<IAiTool, GetIcpTool>();
        services.AddScoped<IAiTool, GetCampaignTool>();
        services.AddScoped<IAiTool, CreateTargetListTool>();
        services.AddScoped<IAiTool, CreateCampaignTool>();
        services.AddScoped<IAiTool, StartCampaignTool>();
        services.AddScoped<IAiTool, RunAutonomousAcquisitionTool>();
        services.AddScoped<IAiToolRegistry, AiToolRegistry>();
        services.AddScoped<IIntegrationRegistry, IntegrationRegistry>();
        services.AddScoped<SalesAutomationService>();
        services.AddScoped<CampaignExecutionService>();
        services.AddScoped<ProspectReplyProcessingService>();
        services.AddScoped<ProspectDiscoveryService>();
        services.AddSingleton<IAutonomousAcquisitionTemplateRegistry, AutonomousAcquisitionTemplateRegistry>();
        services.AddScoped<IAutonomousAcquisitionBackendService, AutonomousAcquisitionBackendService>();
        services.AddScoped<IAutonomousAcquisitionWorkflowPlanner, AutonomousAcquisitionWorkflowPlanner>();
        services.AddScoped<IAgentJobTaskFactory, AgentJobTaskFactory>();
        services.AddScoped<IAutonomousAcquisitionJobOrchestrator, AutonomousAcquisitionJobOrchestrator>();
        services.AddScoped<IAgentJobQueue, AgentJobQueue>();
        services.AddScoped<IAgentJobFactory, AgentJobFactory>();
        services.AddScoped<ICampaignContainerRuntime, CampaignContainerRuntime>();
        services.AddScoped<IAgentJobExecutor, AutonomousAcquisitionJobExecutor>();
        services.AddHostedService<TenantJobWorkerPool>();
        services.AddHttpClient<SerpApiProspectDiscoveryProvider>(c =>
        {
            c.BaseAddress = new Uri("https://serpapi.com/");
            c.Timeout = TimeSpan.FromSeconds(60);
        });
        services.AddScoped<IProspectDiscoveryProvider>(sp => sp.GetRequiredService<SerpApiProspectDiscoveryProvider>());
        services.AddScoped<AutomationActionExecutor>();

        services.AddScoped<IIndustryPackProvisioner, IndustryPackProvisioner>();

        services.AddScoped<LeadsAI.Infrastructure.WorkspacePackages.RealWorkspaceService>();
        services.AddScoped<LeadsAI.Infrastructure.WorkspacePackages.OperationalPackageProvisioner>();
        services.AddScoped<LeadsAI.Infrastructure.WorkspacePackages.WorkspacePackageInstaller>();
        services.AddScoped<DevelopmentSeedService>();
        services.AddHostedService<DevelopmentSeedHostedService>();
        services.AddScoped<IEmailDeliveryProvider, SmtpEmailProvider>();
        services.AddHttpClient<BrevoEmailProvider>(c =>
        {
            c.BaseAddress = new Uri("https://api.brevo.com/v3/");
            c.Timeout = TimeSpan.FromSeconds(60);
        });
        services.AddScoped<IEmailDeliveryProvider>(sp => sp.GetRequiredService<BrevoEmailProvider>());
        services.AddHttpClient<SendGridEmailProvider>();
        services.AddScoped<IEmailDeliveryProvider>(sp => sp.GetRequiredService<SendGridEmailProvider>());
        services.AddScoped<EmailDeliveryService>();

        return services;
    }
}
