using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace LeadsAI.AIOrchestration.Persistence.SqlServer;

public sealed class AIOrchestrationDbContextDesignTimeFactory : IDesignTimeDbContextFactory<AIOrchestrationDbContext>
{
    public AIOrchestrationDbContext CreateDbContext(string[] args)
    {
        var options = new DbContextOptionsBuilder<AIOrchestrationDbContext>()
            .UseSqlServer(DesignConnectionString)
            .Options;

        return new AIOrchestrationDbContext(options);
    }

    private const string DesignConnectionString =
        "Server=localhost;Database=LeadsAI_AIOrchestration_Design;User Id=t24test;Password=DesignOnly123!;TrustServerCertificate=True;Encrypt=False";
}
