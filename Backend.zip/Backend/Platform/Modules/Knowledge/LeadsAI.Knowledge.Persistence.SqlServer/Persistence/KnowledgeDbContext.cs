using Microsoft.EntityFrameworkCore;
using LeadsAI.BuildingBlocks.Messaging.Entitlements;
using LeadsAI.BuildingBlocks.Messaging.Inbox;
using LeadsAI.Knowledge.Domain.KnowledgeBases;

namespace LeadsAI.Knowledge.Persistence.SqlServer;

public sealed class KnowledgeDbContext(DbContextOptions<KnowledgeDbContext> options) : DbContext(options)
{
    public DbSet<KnowledgeBase> KnowledgeBases => Set<KnowledgeBase>();
    public DbSet<TenantEntitlementState> TenantEntitlements => Set<TenantEntitlementState>();
    public DbSet<InboxMessage> InboxMessages => Set<InboxMessage>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(KnowledgeDbContext).Assembly);
        modelBuilder.Entity<TenantEntitlementState>(entity =>
        {
            entity.ToTable("TenantEntitlements");
            entity.HasKey(x => x.TenantId);
            entity.HasIndex(x => x.TenantSlug);
            entity.Property(x => x.TenantSlug).HasMaxLength(128);
            entity.Property(x => x.TenantStatus).HasMaxLength(32);
            entity.Property(x => x.LicensePlan).HasMaxLength(64);
            entity.Property(x => x.LicenseStatus).HasMaxLength(32);
        });
        modelBuilder.Entity<InboxMessage>(entity =>
        {
            entity.ToTable("InboxMessages");
            entity.HasKey(x => new { x.Id, x.Consumer });
            entity.Property(x => x.Consumer).HasMaxLength(200);
        });
        base.OnModelCreating(modelBuilder);
    }
}
