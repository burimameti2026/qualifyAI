using Microsoft.EntityFrameworkCore;
using LeadsAI.Infrastructure.Acquisition;
using LeadsAI.Domain.Core;
using LeadsAI.Persistence.SqlServer;

namespace LeadsAI.Api;
public static class AutonomousAcquisitionVerificationEndpoints
{
 public static IEndpointRouteBuilder MapAutonomousAcquisitionVerification(this IEndpointRouteBuilder app)
 {
  app.MapGet("/api/autonomous-acquisition/verification",async(AppDbContext db,IAutonomousAcquisitionJobOrchestrator orchestrator,IAutonomousAcquisitionTemplateRegistry templates,CancellationToken ct)=>
  {
   var canConnect=await db.Database.CanConnectAsync(ct);
   var agents=await db.AutonomousAcquisitionAgents.CountAsync(ct);
   var runs=await db.AgentJobs.CountAsync(ct);
   var memory=await db.AutonomousAcquisitionAgentMemories.CountAsync(ct);
   var templateCount=templates.List().Count();
   return Results.Ok(new{status=canConnect&&templateCount>0?"ready":"degraded",database=canConnect,orchestrator=orchestrator is not null,templates=templateCount,agents,runs,memory,checkedAtUtc=DateTime.UtcNow});
  });
  return app;
 }
}
