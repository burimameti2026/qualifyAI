using LeadsAI.Infrastructure;

namespace LeadsAI.Api;

public static class TenantLifecycleEndpoints
{
    public static IEndpointRouteBuilder MapTenantLifecycle(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet(
            "/api/tenant-lifecycle/{tenantId:guid}",
            async (Guid tenantId, int? take, ITenantLifecycleEventStore events, CancellationToken ct) =>
                Results.Ok(await events.GetAsync(tenantId, take ?? 100, ct))
        );
        endpoints.MapGet("/api/tenant-alerts/{tenantId:guid}", (Guid tenantId, int? take, ITenantAlertService alerts) => Results.Ok(alerts.Get(tenantId, take ?? 100)));
        endpoints.MapPost("/api/tenant-alerts/{tenantId:guid}/{alertId:guid}/acknowledge", (Guid tenantId, Guid alertId, ITenantAlertService alerts) => { alerts.Acknowledge(tenantId, alertId); return Results.NoContent(); });
        return endpoints;
    }
}
