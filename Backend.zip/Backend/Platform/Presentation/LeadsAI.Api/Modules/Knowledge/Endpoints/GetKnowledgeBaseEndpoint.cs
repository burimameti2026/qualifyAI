using MediatR;
using LeadsAI.Knowledge.Application.KnowledgeBases.Queries.GetById;
namespace LeadsAI.Api.Modules.Knowledge.Endpoints;
public static class GetKnowledgeBaseEndpoint
{
    public static IEndpointRouteBuilder MapGetKnowledgeBase(this IEndpointRouteBuilder app)
    {
        app.MapGet("/knowledge-bases/{id:guid}", async (Guid id, Guid tenantId, ISender sender, CancellationToken ct) =>
        {
            var dto = await sender.Send(new GetKnowledgeBaseByIdQuery(tenantId,id), ct);
            return dto is null ? Results.NotFound() : Results.Ok(dto);
        });
        return app;
    }
}
