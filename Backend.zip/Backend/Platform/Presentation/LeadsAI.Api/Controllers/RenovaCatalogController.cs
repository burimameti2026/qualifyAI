using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LeadsAI.Domain.Core.Catalog;
using LeadsAI.Domain.Core.Portal;
using LeadsAI.Domain.Core.Promotions;
using LeadsAI.Domain;


namespace LeadsAI.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/renova/catalog")]
public sealed class RenovaCatalogController(ITenantContext tenant, AppDbContext db) : ControllerBase
{
    private Guid TenantId => tenant.TenantId();
    private const string SiteContentKey = "renova.portal.content.v1";

    [HttpGet("site-content")]
    public async Task<IActionResult> SiteContent(CancellationToken ct)
    {
        var setting = await db.TenantSettings.AsNoTracking().SingleOrDefaultAsync(x => x.TenantId == TenantId && x.Key == SiteContentKey, ct);
        if (setting is null || string.IsNullOrWhiteSpace(setting.Value)) return NotFound(new { code = "site_content_not_seeded" });
        return Content(setting.Value, "application/json");
    }

    [HttpPut("site-content")]
    public async Task<IActionResult> UpdateSiteContent([FromBody] RenovaSiteContentDocument request, CancellationToken ct)
    {
        request.Status = string.Equals(request.Status, "Draft", StringComparison.OrdinalIgnoreCase) ? "Draft" : "Published";
        request.Version = Math.Max(1, request.Version + 1);
        request.UpdatedAtUtc = DateTimeOffset.UtcNow;
        var setting = await db.TenantSettings.SingleOrDefaultAsync(x => x.TenantId == TenantId && x.Key == SiteContentKey, ct);
        var json = JsonSerializer.Serialize(request);
        if (setting is null)
            db.TenantSettings.Add(new TenantSetting { TenantId = TenantId, Key = SiteContentKey, Value = json });
        else
            setting.Value = json;
        await db.SaveChangesAsync(ct);
        return Ok(request);
    }

    [HttpPost("site-content/publish")]
    public async Task<IActionResult> PublishSiteContent(CancellationToken ct)
        => await SetSiteContentStatusAsync("Published", ct);

    [HttpPost("site-content/unpublish")]
    public async Task<IActionResult> UnpublishSiteContent(CancellationToken ct)
        => await SetSiteContentStatusAsync("Draft", ct);

    private async Task<IActionResult> SetSiteContentStatusAsync(string status, CancellationToken ct)
    {
        var setting = await db.TenantSettings.SingleOrDefaultAsync(x => x.TenantId == TenantId && x.Key == SiteContentKey, ct);
        if (setting is null) return NotFound(new { code = "site_content_not_seeded" });
        var content = JsonSerializer.Deserialize<RenovaSiteContentDocument>(setting.Value) ?? new();
        content.Status = status;
        content.Version = Math.Max(1, content.Version + 1);
        content.UpdatedAtUtc = DateTimeOffset.UtcNow;
        setting.Value = JsonSerializer.Serialize(content);
        await db.SaveChangesAsync(ct);
        return Ok(content);
    }

    [HttpGet("categories")]
    public async Task<IActionResult> Categories(CancellationToken ct)
    {
        var tenantId = TenantId;
        var categories = await db.ProductCategories.Where(x => x.TenantId == tenantId && x.IsActive).OrderBy(x => x.SortOrder).ThenBy(x => x.Name).ToListAsync(ct);
        if (categories.Count == 0)
        {
            categories = [
                new ProductCategory { TenantId = tenantId, Name = "Plasters / Putz", Code = "PUTZ", SortOrder = 10 },
                new ProductCategory { TenantId = tenantId, Name = "Adhesives", Code = "ADH", SortOrder = 20 },
                new ProductCategory { TenantId = tenantId, Name = "Primers", Code = "PRIMER", SortOrder = 30 },
                new ProductCategory { TenantId = tenantId, Name = "Exterior Solutions", Code = "EXT", SortOrder = 40 }
            ];
            db.ProductCategories.AddRange(categories);
            await db.SaveChangesAsync(ct);
        }
        return Ok(categories);
    }

    [HttpPost("categories")]
    public async Task<IActionResult> CreateCategory(ProductCategory item, CancellationToken ct)
    {
        item.Id = Guid.NewGuid(); item.TenantId = TenantId; db.ProductCategories.Add(item); await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpGet("products")]
    public async Task<IActionResult> Products(CancellationToken ct) => Ok(await db.CatalogProducts.Where(x => x.TenantId == TenantId && x.IsActive).OrderBy(x => x.Name).Select(x => new
    {
        x.Id, x.Name, x.Code, x.Brand, x.ShortDescription, x.ProductCategoryId,
        variants = db.ProductVariants.Count(v => v.TenantId == TenantId && v.CatalogProductId == x.Id && v.IsActive),
        languages = db.ProductLocalizations.Where(l => l.TenantId == TenantId && l.CatalogProductId == x.Id).Select(l => l.Language).Distinct().OrderBy(l => l).ToList(),
        publication = db.PortalPublications.Where(p => p.TenantId == TenantId && p.CatalogProductId == x.Id).Select(p => new { p.Status, p.IsVisible, p.Version, p.Slug }).FirstOrDefault()
    }).ToListAsync(ct));

    [HttpGet("products/{id:guid}")]
    public async Task<IActionResult> Product(Guid id, CancellationToken ct)
    {
        var product = await db.CatalogProducts.SingleOrDefaultAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct);
        if (product is null) return NotFound();
        return Ok(new { product, variants = await db.ProductVariants.Where(x => x.CatalogProductId == id && x.TenantId == TenantId && x.IsActive).ToListAsync(ct), assets = await db.ProductAssets.Where(x => x.CatalogProductId == id && x.TenantId == TenantId).ToListAsync(ct), localizations = await db.ProductLocalizations.Where(x => x.CatalogProductId == id && x.TenantId == TenantId).ToListAsync(ct), publication = await db.PortalPublications.SingleOrDefaultAsync(x => x.CatalogProductId == id && x.TenantId == TenantId, ct) });
    }

    [HttpPost("products")]
    public async Task<IActionResult> CreateProduct(CatalogProduct item, CancellationToken ct)
    {
        item.Id = Guid.NewGuid(); item.TenantId = TenantId; item.CreatedAt = DateTimeOffset.UtcNow;
        if (!await db.ProductCategories.AnyAsync(x => x.Id == item.ProductCategoryId && x.TenantId == TenantId && x.IsActive, ct)) return BadRequest(new { code = "category_not_found" });
        if (await db.CatalogProducts.AnyAsync(x => x.TenantId == TenantId && x.Code == item.Code, ct)) return Conflict(new { code = "product_code_exists" });
        db.CatalogProducts.Add(item); await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpPut("products/{id:guid}")]
    public async Task<IActionResult> UpdateProduct(Guid id, CatalogProduct request, CancellationToken ct)
    {
        var item = await db.CatalogProducts.SingleOrDefaultAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct); if (item is null) return NotFound();
        if (!await db.ProductCategories.AnyAsync(x => x.Id == request.ProductCategoryId && x.TenantId == TenantId && x.IsActive, ct)) return BadRequest(new { code = "category_not_found" });
        if (await db.CatalogProducts.AnyAsync(x => x.TenantId == TenantId && x.Code == request.Code.Trim() && x.Id != id, ct)) return Conflict(new { code = "product_code_exists" });
        item.ProductCategoryId = request.ProductCategoryId; item.Name = request.Name.Trim(); item.Code = request.Code.Trim(); item.Brand = request.Brand?.Trim(); item.ShortDescription = request.ShortDescription?.Trim(); item.Description = request.Description?.Trim(); item.KeyBenefits = request.KeyBenefits?.Trim(); item.Applications = request.Applications?.Trim(); item.TechnicalSpecifications = request.TechnicalSpecifications?.Trim(); item.UpdatedAt = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpPost("products/{id:guid}/variants")]
    public async Task<IActionResult> AddVariant(Guid id, ProductVariant item, CancellationToken ct)
    {
        if (!await db.CatalogProducts.AnyAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct)) return NotFound();
        item.Id = Guid.NewGuid(); item.TenantId = TenantId; item.CatalogProductId = id; db.ProductVariants.Add(item); await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpPost("products/{id:guid}/assets")]
    public async Task<IActionResult> AddAsset(Guid id, ProductAsset item, CancellationToken ct)
    {
        if (!await db.CatalogProducts.AnyAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct)) return NotFound();
        item.Id = Guid.NewGuid(); item.TenantId = TenantId; item.CatalogProductId = id; db.ProductAssets.Add(item); await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpPut("products/{id:guid}/localizations/{language}")]
    public async Task<IActionResult> UpsertLocalization(Guid id, string language, ProductLocalization request, CancellationToken ct)
    {
        language = NormalizeLanguage(language); var product = await db.CatalogProducts.SingleOrDefaultAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct); if (product is null) return NotFound();
        var item = await db.ProductLocalizations.SingleOrDefaultAsync(x => x.TenantId == TenantId && x.CatalogProductId == id && x.Language == language, ct);
        if (item is null) { request.Id = Guid.NewGuid(); request.TenantId = TenantId; request.CatalogProductId = id; request.Language = language; db.ProductLocalizations.Add(request); item = request; }
        else { item.Name = request.Name; item.ShortDescription = request.ShortDescription; item.Description = request.Description; item.KeyBenefits = request.KeyBenefits; item.Applications = request.Applications; }
        await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpPost("products/{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id, [FromBody] PublishProductRequest? request, CancellationToken ct)
    {
        var product = await db.CatalogProducts.SingleOrDefaultAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct); if (product is null) return NotFound(); request ??= new PublishProductRequest(null);
        var publication = await db.PortalPublications.SingleOrDefaultAsync(x => x.CatalogProductId == id && x.TenantId == TenantId, ct);
        if (publication is null) { publication = new PortalPublication { TenantId = TenantId, CatalogProductId = id, Slug = string.IsNullOrWhiteSpace(request.Slug) ? Slug(product.Name, id) : Slug(request.Slug, id), Status = "Published", IsVisible = true, PublishedAt = DateTimeOffset.UtcNow }; db.PortalPublications.Add(publication); }
        else { publication.Status = "Published"; publication.IsVisible = true; if (!string.IsNullOrWhiteSpace(request.Slug)) publication.Slug = Slug(request.Slug, id); publication.Version++; publication.PublishedAt = DateTimeOffset.UtcNow; publication.UpdatedAt = DateTimeOffset.UtcNow; }
        await db.SaveChangesAsync(ct); return Ok(publication);
    }

    [HttpPost("products/{id:guid}/unpublish")]
    public async Task<IActionResult> Unpublish(Guid id, CancellationToken ct)
    {
        var publication = await db.PortalPublications.SingleOrDefaultAsync(x => x.CatalogProductId == id && x.TenantId == TenantId, ct); if (publication is null) return NotFound(); publication.Status = "Draft"; publication.IsVisible = false; publication.UpdatedAt = DateTimeOffset.UtcNow; await db.SaveChangesAsync(ct); return Ok(publication);
    }

    [HttpGet("products/{id:guid}/markets")]
    public Task<List<TargetMarket>> Markets(Guid id, CancellationToken ct) => db.TargetMarkets.AsNoTracking().Where(x => x.TenantId == TenantId && x.CatalogProductId == id && x.IsActive).OrderBy(x => x.CountryName).ToListAsync(ct);

    [HttpPost("products/{id:guid}/markets")]
    public async Task<IActionResult> AddMarket(Guid id, TargetMarket item, CancellationToken ct)
    {
        if (!await db.CatalogProducts.AnyAsync(x => x.Id == id && x.TenantId == TenantId && x.IsActive, ct)) return NotFound();
        item.Id = Guid.NewGuid(); item.TenantId = TenantId; item.CatalogProductId = id; item.CountryCode = item.CountryCode.Trim().ToUpperInvariant(); item.DefaultLanguage = NormalizeLanguage(item.DefaultLanguage);
        var existing = await db.TargetMarkets.SingleOrDefaultAsync(x => x.TenantId == TenantId && x.CatalogProductId == id && x.CountryCode == item.CountryCode, ct);
        if (existing is not null) return Ok(existing);
        db.TargetMarkets.Add(item); await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpGet("promotion-plans")]
    public Task<List<ProductPromotionPlan>> PromotionPlans(CancellationToken ct) => db.ProductPromotionPlans.AsNoTracking().Where(x => x.TenantId == TenantId).OrderByDescending(x => x.CreatedAt).ToListAsync(ct);

    [HttpPost("promotion-plans")]
    public async Task<IActionResult> CreatePlan(ProductPromotionPlan item, CancellationToken ct)
    {
        if (!await db.CatalogProducts.AnyAsync(x => x.Id == item.CatalogProductId && x.TenantId == TenantId && x.IsActive, ct)) return BadRequest(new { code = "product_not_found" });
        if (!await db.TargetMarkets.AnyAsync(x => x.Id == item.TargetMarketId && x.TenantId == TenantId && x.CatalogProductId == item.CatalogProductId && x.IsActive, ct)) return BadRequest(new { code = "target_market_not_found" });
        item.Id = Guid.NewGuid(); item.TenantId = TenantId; item.CreatedAt = DateTimeOffset.UtcNow; item.CampaignLanguage = NormalizeLanguage(item.CampaignLanguage); item.Status = string.IsNullOrWhiteSpace(item.Status) ? "Draft" : item.Status; db.ProductPromotionPlans.Add(item); await db.SaveChangesAsync(ct); return Ok(item);
    }

    [HttpPost("promotion-plans/{id:guid}/activate")]
    public async Task<IActionResult> ActivatePlan(Guid id, CancellationToken ct)
    {
        var plan = await db.ProductPromotionPlans.SingleOrDefaultAsync(x => x.Id == id && x.TenantId == TenantId, ct); if (plan is null) return NotFound(); plan.Status = "Active"; plan.ActivatedAt = DateTimeOffset.UtcNow; await db.SaveChangesAsync(ct); return Ok(plan);
    }

    private static string NormalizeLanguage(string value) => value.Trim().ToLowerInvariant() switch { "mk" or "mk-mk" => "mk", "sq" or "sq-al" => "sq", "de" or "de-de" => "de", _ => "en" };
    private static string Slug(string value, Guid id) { var slug = string.Join('-', value.Trim().ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries)); return string.IsNullOrWhiteSpace(slug) ? id.ToString("N") : $"{slug}-{id.ToString("N")[..8]}"; }
}

public sealed record PublishProductRequest(string? Slug);
