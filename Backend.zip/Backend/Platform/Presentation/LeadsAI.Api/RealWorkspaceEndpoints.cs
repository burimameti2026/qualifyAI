using Microsoft.EntityFrameworkCore;
using LeadsAI.BuildingBlocks.Security.Tenancy;
using LeadsAI.Domain;
using LeadsAI.Infrastructure.Acquisition;
using LeadsAI.Domain.Core;

namespace LeadsAI.Api;

public static class RealWorkspaceEndpoints
{
    public static IEndpointRouteBuilder MapRealWorkspace(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/real-workspace");

        g.MapGet("/options", (IAutonomousAcquisitionTemplateRegistry templates) => Results.Ok(new
        {
            useCases = new[]
            {
                new { id = "autonomous-acquisition", name = "Autonomous Acquisition", description = "Automatically discover, enrich, qualify and route prospects for this tenant." }
            },
            templates = templates.List().Select(t => new
            {
                id = t.Code,
                name = t.Name,
                useCaseId = "autonomous-acquisition",
                description = $"{t.Industry} prospecting in {t.Region}.",
                requiredModules = new[] { "acquisition", "automation" }
            }),
            schedule = "daily"
        }));

        g.MapPost("/prepare", async (RealWorkspaceRequest request, ICurrentTenant currentTenant, AppDbContext db, IAutonomousAcquisitionTemplateRegistry templates, IAgentJobFactory jobFactory, ICampaignContainerRuntime containers, CancellationToken ct) =>
        {
            var tenantId = ResolveTenant(request, currentTenant);
            if (tenantId is null) return Results.BadRequest(new { error = "The selected workspace does not belong to the current tenant." });

            var scopedRequest = request with { TenantId = tenantId.Value };
            var result = await PrepareAndQueueAsync(scopedRequest, db, templates, jobFactory, containers, ct);
            return Results.Accepted($"/api/real-workspace/tenants/{tenantId.Value}", result);
        });


        return app;
    }

    private static Guid? ResolveTenant(RealWorkspaceRequest request, ICurrentTenant currentTenant)
    {
        if (!currentTenant.IsResolved) return null;
        if (request.TenantId != Guid.Empty && request.TenantId != currentTenant.Id) return null;
        return currentTenant.Id;
    }

    private static async Task<RealWorkspaceResult> PrepareAndQueueAsync(
        RealWorkspaceRequest request,
        AppDbContext db,
        IAutonomousAcquisitionTemplateRegistry templates,
        IAgentJobFactory jobFactory,
        ICampaignContainerRuntime containers,
        CancellationToken ct)
    {
        var agent = await EnsureAgent(request, db, templates, ct);
        var workspace = await EnsureCampaignWorkspace(request, agent, db, ct);

        agent.Status = AutonomousAgentStatus.Active;
        agent.UpdatedAtUtc = DateTime.UtcNow;
        workspace.Campaign.AgentId = agent.Id;
        workspace.Campaign.Status = CampaignStatus.Running;

        var container = await containers.EnsureAsync(
            request.TenantId,
            workspace.Campaign.Id,
            agent.Id,
            $"{workspace.Campaign.Name} Container",
            workspace.Campaign.PackageCode,
            workspace.Campaign.PackageVersion,
            workspace.Campaign.PlanJson,
            ct);

        var existing = await db.AgentJobs.AsNoTracking()
            .Where(x => x.TenantId == request.TenantId &&
                        x.CampaignId == workspace.Campaign.Id &&
                        (x.Status == AgentJobStatus.Queued || x.Status == AgentJobStatus.Running || x.Status == AgentJobStatus.Waiting))
            .OrderByDescending(x => x.CreatedAtUtc)
            .FirstOrDefaultAsync(ct);

        await db.SaveChangesAsync(ct);

        var job = existing ?? await jobFactory.QueueCampaignAsync(
            request.TenantId,
            workspace.Campaign.Id,
            agent.Id,
            container.Id,
            "campaign.execute",
            $"campaign:{workspace.Campaign.Id}",
            true,
            ct);

        return new RealWorkspaceResult(
            request.TenantId,
            agent.Id,
            agent.Name,
            agent.Status.ToString(),
            job.Id,
            existing is not null ? "already-queued" : "activation-queued",
            workspace.TargetList.Id,
            workspace.Campaign.Id);
    }

    private static async Task<(TargetList TargetList, Campaign Campaign)> EnsureCampaignWorkspace(RealWorkspaceRequest request, AutonomousAcquisitionAgent agent, AppDbContext db, CancellationToken ct)
    {
        var workspaceName = string.IsNullOrWhiteSpace(request.Name) ? agent.Name : request.Name.Trim();
        var targetListName = $"{workspaceName} — Qualified Prospects";
        var targetList = await db.TargetLists.FirstOrDefaultAsync(x => x.TenantId == request.TenantId && x.Name == targetListName, ct);
        if (targetList is null)
        {
            targetList = new TargetList { Id = Guid.NewGuid(), TenantId = request.TenantId, Name = targetListName, Description = "Qualified prospects produced by the autonomous acquisition agent.", Dynamic = true };
            db.TargetLists.Add(targetList);
        }

        var campaignName = $"{workspaceName} — Acquisition Campaign";
        var campaign = await db.Campaigns.FirstOrDefaultAsync(x => x.TenantId == request.TenantId && x.Name == campaignName, ct);
        if (campaign is null)
        {
            campaign = new Campaign
            {
                Id = Guid.NewGuid(),
                TenantId = request.TenantId,
                TargetListId = targetList.Id,
                Name = campaignName,
                Goal = "book-demo",
                SenderName = string.Empty,
                SenderEmail = string.Empty
            };
            db.Campaigns.Add(campaign);
        }
        else
        {
            campaign.TargetListId = targetList.Id;
        }

        return (targetList, campaign);
    }

    private static async Task<AutonomousAcquisitionAgent> EnsureAgent(RealWorkspaceRequest request, AppDbContext db, IAutonomousAcquisitionTemplateRegistry templates, CancellationToken ct)
    {
        var requestedName = string.IsNullOrWhiteSpace(request.Name) ? null : request.Name.Trim();
        var defaultName = string.Equals(request.TemplateKey, "fleet", StringComparison.OrdinalIgnoreCase)
            ? "FusionFleet Autonomous Acquisition"
            : "Real Workspace Acquisition";
        var agentName = requestedName ?? defaultName;
        var agent = await db.AutonomousAcquisitionAgents.FirstOrDefaultAsync(x => x.TenantId == request.TenantId && x.Name == agentName, ct);

        if (agent is null)
        {
            agent = new AutonomousAcquisitionAgent
            {
                Id = Guid.NewGuid(),
                TenantId = request.TenantId,
                Name = agentName,
                TemplateCode = request.TemplateKey ?? "custom",
                Industry = request.Industry ?? string.Empty,
                Region = request.Region ?? string.Empty,
                CountriesJson = request.CountriesJson ?? "[]",
                DailyDiscoveryLimit = request.DailyDiscoveryLimit > 0 ? request.DailyDiscoveryLimit : 25,
                MinimumScore = request.MinimumScore > 0 ? request.MinimumScore : 70,
                RunTimeUtc = request.RunTimeUtc ?? new TimeOnly(8, 0),
                Status = AutonomousAgentStatus.Draft,
                CreatedAtUtc = DateTime.UtcNow,
                UpdatedAtUtc = DateTime.UtcNow
            };
            templates.Apply(agent);
            db.AutonomousAcquisitionAgents.Add(agent);
        }
        else
        {
            if (!string.IsNullOrWhiteSpace(request.TemplateKey)) agent.TemplateCode = request.TemplateKey;
            if (!string.IsNullOrWhiteSpace(request.Industry)) agent.Industry = request.Industry;
            if (!string.IsNullOrWhiteSpace(request.Region)) agent.Region = request.Region;
            if (!string.IsNullOrWhiteSpace(request.CountriesJson)) agent.CountriesJson = request.CountriesJson;
            if (request.DailyDiscoveryLimit > 0) agent.DailyDiscoveryLimit = request.DailyDiscoveryLimit;
            if (request.MinimumScore > 0) agent.MinimumScore = request.MinimumScore;
            if (request.RunTimeUtc.HasValue) agent.RunTimeUtc = request.RunTimeUtc.Value;
            agent.UpdatedAtUtc = DateTime.UtcNow;
            templates.Apply(agent);
        }

        await db.SaveChangesAsync(ct);
        return agent;
    }
}

public sealed record RealWorkspaceRequest(Guid TenantId, string? Name, string? UseCase, string? TemplateKey, string? Industry, string? Region, string? CountriesJson, int DailyDiscoveryLimit = 25, int MinimumScore = 70, TimeOnly? RunTimeUtc = null);
public sealed record RealWorkspaceResult(Guid TenantId, Guid AgentId, string AgentName, string AgentStatus, Guid? InitialRunId, string Status, Guid? TargetListId, Guid? CampaignId);